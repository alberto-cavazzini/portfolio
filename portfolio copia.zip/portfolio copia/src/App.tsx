import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import About from "./components/About";
import Contact from "./components/Contact";
import Projects from "./pages/Projects";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer"; // Importa il componente Footer
import "./App.css";
import LoadingScreen from "./components/LoadingScreen";
import ProjectDetail from "./components/ProjectDetail"; // Importa il componente ProjectDetail

function App() {
  const [isLoading, setIsLoading] = useState(true);

  const handleLoadingComplete = () => {
    setIsLoading(false);
  };
  // Sostituisci con l'URL del tuo curriculum su Figma
  const resumeUrl =
    "https://www.figma.com/file/IL_TUO_ID_FILE/Il-tuo-Curriculum?type=design&node-id=0%3A1&mode=design&t=XYZ123abc-def4-5678-9ghi-jklm0nopqrs";

  return (
    <Router>
      <div>
        {isLoading ? (
          <LoadingScreen onComplete={handleLoadingComplete} />
        ) : (
          <>
            <Navbar resumeUrl={resumeUrl} />
            <Routes>
              <Route path="/" element={<About />} />
              <Route path="/projects" element={<Projects />} />
              <Route
                path="/projects/:caseStudyId"
                element={<ProjectDetail />}
              />{" "}
              {/* Aggiungi questa rotta */}
              <Route path="/contact" element={<Contact />} />
            </Routes>
            <Footer /> {/* Renderizza il componente Footer qui */}
          </>
        )}
      </div>
    </Router>
  );
}

export default App;
