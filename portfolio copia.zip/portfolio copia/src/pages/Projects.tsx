import React from "react";
import ProjectCard from "../components/ProjectCard";
import "./Projects.css"; // Importa il file CSS se lo crei

// Definisci un'interfaccia per i dati del progetto per una migliore tipizzazione
interface Project {
  title: string;
  description: string;
  imageUrl: string;
  liveUrl?: string;
  codeUrl?: string;
  hasCaseStudy?: boolean;
  caseStudyId?: string; // Un ID per recuperare i dati della case study
}

// Array di esempio dei tuoi progetti
const projects: Project[] = [
  {
    title: "Titolo Progetto 1",
    description: "Breve descrizione...",
    imageUrl: "/images/project1.png",
    liveUrl: "https://esempio1.com",
    codeUrl: "https://github.com/...",
    hasCaseStudy: true,
    caseStudyId: "progetto1", // Identificatore unico
  },
  {
    title: "Titolo Progetto 2",
    description: "Breve descrizione...",
    imageUrl: "/images/project2.png",
    liveUrl: "https://esempio2.net",
    codeUrl: "https://github.com/...",
    hasCaseStudy: false,
  },
  {
    title: "Titolo",
    description:
      "Una breve descrizione del Progetto Esempio 2. Descrivi le sfide affrontate e le soluzioni implementate.",
    imageUrl: "/images/project2.png", // Assicurati che l'immagine sia nella cartella public/images
    liveUrl: "https://esempio2.net",
    codeUrl: "https://github.com/iltuonome/progetto2",
  },
  {
    title: "Titolo",
    description:
      "Una breve descrizione del Progetto Esempio 2. Descrivi le sfide affrontate e le soluzioni implementate.",
    imageUrl: "/images/project2.png", // Assicurati che l'immagine sia nella cartella public/images
    liveUrl: "https://esempio2.net",
    codeUrl: "https://github.com/iltuonome/progetto2",
  },
  {
    title: "Titolo",
    description:
      "Una breve descrizione del Progetto Esempio 2. Descrivi le sfide affrontate e le soluzioni implementate.",
    imageUrl: "/images/project2.png", // Assicurati che l'immagine sia nella cartella public/images
    liveUrl: "https://esempio2.net",
    codeUrl: "https://github.com/iltuonome/progetto2",
  },
  // Aggiungi altri progetti qui...
];

function Projects() {
  return (
    <section className="projects">
      <div className="container">
        <h2>Progetti</h2>
        <div className="projects-grid">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
