import React from "react";
import "./CaseStudy.css"; // Crea anche un file CSS per la case study

interface CaseStudyProps {
  project: {
    title: string;
    overview: {
      introduction: string;
      role: string;
      objectives: string;
    };
    challenge: {
      problem: string;
      constraints?: string;
      userNeeds?: string;
    };
    process: {
      researchAnalysis?: string;
      uiDesign: string;
      backendLogic: string;
      developmentImplementation: string;
      testingIteration?: string;
    };
    solution: {
      presentation: string; // Potrebbe essere un percorso immagine o un componente
      keyFeatures: string[];
      challengeSolution: string;
    };
    results?: {
      metrics?: string;
      userFeedback?: string;
      learnings: string;
    };
    technologies: string[];
    personalReflections: string;
    callToAction?: string;
    liveUrl?: string;
    codeUrl?: string;
  };
}

const CaseStudy: React.FC<CaseStudyProps> = ({ project }) => {
  return (
    <div className="case-study">
      <header className="case-study-header">
        <h1>{project.title}</h1>
      </header>

      <section className="overview">
        <h2>Panoramica</h2>
        <p>
          <strong>Introduzione:</strong> {project.overview.introduction}
        </p>
        <p>
          <strong>Il mio ruolo:</strong> {project.overview.role}
        </p>
        <p>
          <strong>Obiettivi:</strong> {project.overview.objectives}
        </p>
      </section>

      <section className="challenge">
        <h2>La Sfida</h2>
        <p>
          <strong>Problema:</strong> {project.challenge.problem}
        </p>
        {project.challenge.constraints && (
          <p>
            <strong>Vincoli:</strong> {project.challenge.constraints}
          </p>
        )}
        {project.challenge.userNeeds && (
          <p>
            <strong>Esigenze degli utenti:</strong>{" "}
            {project.challenge.userNeeds}
          </p>
        )}
      </section>

      <section className="process">
        <h2>Il Processo</h2>
        {project.process.researchAnalysis && (
          <p>
            <strong>Ricerca e analisi:</strong>{" "}
            {project.process.researchAnalysis}
          </p>
        )}
        <p>
          <strong>Progettazione UI:</strong> {project.process.uiDesign}
        </p>
        <p>
          <strong>Logica Backend:</strong> {project.process.backendLogic}
        </p>
        <p>
          <strong>Sviluppo e implementazione:</strong>{" "}
          {project.process.developmentImplementation}
        </p>
        {project.process.testingIteration && (
          <p>
            <strong>Test e iterazione:</strong>{" "}
            {project.process.testingIteration}
          </p>
        )}
      </section>

      <section className="solution">
        <h2>La Soluzione</h2>
        <div className="solution-presentation">
          {/* Qui potresti mostrare un'immagine o un video del progetto: */}
          <p>{project.solution.presentation}</p>
        </div>
        <h3>Caratteristiche principali</h3>
        <ul>
          {project.solution.keyFeatures.map((feature, index) => (
            <li key={index}>{feature}</li>
          ))}
        </ul>
        <p>
          <strong>Come la soluzione ha affrontato la sfida:</strong>{" "}
          {project.solution.challengeSolution}
        </p>
      </section>

      {project.results && (
        <section className="results">
          <h2>Risultati</h2>
          {project.results.metrics && (
            <p>
              <strong>Metriche:</strong> {project.results.metrics}
            </p>
          )}
          {project.results.userFeedback && (
            <p>
              <strong>Feedback degli utenti:</strong>{" "}
              {project.results.userFeedback}
            </p>
          )}
          <p>
            <strong>Apprendimenti:</strong> {project.results.learnings}
          </p>
        </section>
      )}

      <section className="technologies">
        <h2>Tecnologie Utilizzate</h2>
        <ul>
          {project.technologies.map((tech, index) => (
            <li key={index}>{tech}</li>
          ))}
        </ul>
      </section>

      <section className="personal-reflections">
        <h2>Riflessioni Personali</h2>
        <p>{project.personalReflections}</p>
      </section>

      {project.callToAction && (
        <section className="call-to-action">
          <p>{project.callToAction}</p>
          {project.liveUrl && (
            <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
              Vai al Progetto
            </a>
          )}
          {project.codeUrl && (
            <a href={project.codeUrl} target="_blank" rel="noopener noreferrer">
              Vedi il Codice
            </a>
          )}
        </section>
      )}
    </div>
  );
};

export default CaseStudy;
