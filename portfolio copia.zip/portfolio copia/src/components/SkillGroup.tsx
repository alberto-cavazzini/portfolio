// SkillGroupComponent.tsx
import React from "react";
import { motion, AnimatePresence } from "framer-motion";

interface Skill {
  name: string;
  description: string;
}

interface SkillGroup {
  title: string;
  skills: Skill[];
}

// Componente per visualizzare una singola competenza
const SkillItem: React.FC<{
  skill: Skill;
  expandedSkill: string | null;
  groupTitle: string;
  onToggle: (skillName: string, groupTitle: string) => void;
  skillItemVariants: any;
  hasAnimated: boolean;
}> = ({
  skill,
  expandedSkill,
  groupTitle,
  onToggle,
  skillItemVariants,
  hasAnimated,
}) => {
  return (
    <React.Fragment key={skill.name}>
      <motion.div
        variants={skillItemVariants}
        initial="hidden"
        animate={hasAnimated ? "visible" : "hidden"}
        whileHover="whileHover"
        whileTap="whileTap"
        className={`skill-item ${
          expandedSkill === skill.name ? "expanded" : ""
        }`}
        onClick={() => onToggle(skill.name, groupTitle)}
      >
        <strong>{skill.name}</strong>
      </motion.div>
    </React.Fragment>
  );
};

const SkillGroupComponent: React.FC<{
  group: SkillGroup;
  expandedSkill: string | null;
  expandedGroup: string | null;
  onToggle: (skillName: string, groupTitle: string) => void;
  hasAnimated: boolean;
  skillItemVariants: any;
}> = ({
  group,
  expandedSkill,
  expandedGroup,
  onToggle,
  hasAnimated,
  skillItemVariants,
}) => {
  const descriptionVariants = {
    initial: { opacity: 0, height: 0 },
    animate: {
      opacity: 1,
      height: "auto",
      transition: { duration: 0.3, ease: "easeInOut" },
    },
    exit: {
      opacity: 0,
      height: 0,
      transition: { duration: 0.2, ease: "easeInOut" },
    },
  };

  return (
    <div className="skills-group" key={group.title}>
      <h4>{group.title}</h4>
      <div className="skills-row">
        {group.skills.map((skill) => (
          <SkillItem
            key={skill.name}
            skill={skill}
            expandedSkill={expandedSkill}
            groupTitle={group.title}
            onToggle={onToggle}
            skillItemVariants={skillItemVariants} // Passa variants
            hasAnimated={hasAnimated}
          />
        ))}
      </div>
      <AnimatePresence>
        {expandedGroup === group.title && expandedSkill && (
          <motion.div
            className="skill-description"
            variants={descriptionVariants}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            {group.skills.find((skill) => skill.name === expandedSkill)
              ?.description || ""}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export { SkillGroupComponent };
