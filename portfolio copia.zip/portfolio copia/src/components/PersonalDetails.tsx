// PersonalDetails.tsx
import React from "react";

const PersonalDetails: React.FC = () => {
  return (
    <div className="personal-details">
      <h3>Dettagli personali</h3>
      <ul>
        <li>
          <strong>Nome:</strong> Alberto Cavazzini
        </li>
        <li>
          <strong>Città:</strong> Bologna, Italy
        </li>
        <li>
          <strong>Email:</strong>{" "}
          <a href="mailto:alberto.cavazzini97@gmail.com">
            alberto.cavazzini97@gmail.com
          </a>
        </li>
        <li>
          <strong>LinkedIn:</strong>{" "}
          <a
            href="https://www.linkedin.com/in/alberto-cavazzini-dev/"
            target="_blank"
            rel="noopener noreferrer"
          >
            Il mio profilo LinkedIn
          </a>
        </li>
        <li>
          <strong>GitHub:</strong>{" "}
          <a
            href="https://github.com/albertocavazzini"
            target="_blank"
            rel="noopener noreferrer"
          >
            Il mio profilo GitHub
          </a>
        </li>
        {/* Puoi aggiungere altri dettagli se lo desideri */}
      </ul>
    </div>
  );
};

export { PersonalDetails };
