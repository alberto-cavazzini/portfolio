import React, { useState, useEffect } from "react";
import "./LoadingScreen.css"; // Crea anche un file LoadingScreen.css

interface LoadingScreenProps {
  onComplete: () => void; // Funzione da chiamare quando il conto alla rovescia è finito
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [count, setCount] = useState(3);

  useEffect(() => {
    if (count > 0) {
      const timer = setTimeout(() => {
        setCount((prevCount) => prevCount - 1);
      }, 1000);
      return () => clearTimeout(timer); // Cleanup del timer
    } else {
      onComplete(); // Chiama la funzione per mostrare il sito
    }
  }, [count, onComplete]);

  return (
    <div className="loading-screen">
      <h1>Entrerai nel mio mondo tra...</h1>
      <div className="countdown">{count}</div>
    </div>
  );
};

export default LoadingScreen;
