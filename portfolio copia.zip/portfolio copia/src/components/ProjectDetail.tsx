// ProjectDetail.tsx
import React from "react";
import { useParams } from "react-router-dom";
import CaseStudy from "../components/CaseStudy";

interface CaseStudyData {
  [key: string]: {
    // Indica che l'oggetto può avere proprietà stringa con la seguente struttura
    title: string;
    overview: {
      introduction: string;
      role: string;
      objectives: string;
    };
    challenge: {
      problem: string;
      constraints?: string;
      userNeeds?: string;
    };
    process: {
      researchAnalysis?: string;
      uiDesign: string;
      backendLogic: string;
      developmentImplementation: string;
      testingIteration?: string;
    };
    solution: {
      presentation: string;
      keyFeatures: string[];
      challengeSolution: string;
    };
    results?: {
      metrics?: string;
      userFeedback?: string;
      learnings: string;
    };
    technologies: string[];
    personalReflections: string;
    callToAction?: string;
    liveUrl?: string;
    codeUrl?: string;
  };
}

// *** IMPORTANTE: Popola questo oggetto con i DATI DELLA TUA CASE STUDY ***
const caseStudiesData: CaseStudyData = {
  progetto1: {
    // Sostituisci 'progetto1' con l'effettivo caseStudyId del tuo progetto
    title: "Nome del Tuo Progetto 1",
    overview: {
      introduction: "Breve introduzione accattivante del progetto.",
      role: "Il mio ruolo in questo progetto è stato lo sviluppo full-stack.",
      objectives:
        "L'obiettivo principale era creare un'applicazione web per [scopo] che fosse user-friendly e performante.",
    },
    challenge: {
      problem:
        "La sfida principale era sviluppare un'interfaccia intuitiva per gestire una grande quantità di dati.",
      constraints: "Il progetto aveva un vincolo di tempo di [durata].",
      userNeeds:
        "Gli utenti avevano bisogno di un modo semplice ed efficiente per [esigenza].",
    },
    process: {
      researchAnalysis:
        "Ho condotto una breve analisi della concorrenza per capire le migliori pratiche.",
      uiDesign:
        "Ho iniziato con wireframe a bassa fedeltà, seguiti da prototipi in Figma per testare il flusso utente.",
      backendLogic:
        "Il backend è stato sviluppato utilizzando Node.js ed Express, con un database MongoDB per la gestione dei dati.",
      developmentImplementation:
        "Ho lavorato in un team di due persone, concentrandomi sullo sviluppo del frontend con React e sull'integrazione con le API backend.",
      testingIteration:
        "Abbiamo condotto test interni e raccolto feedback che ha portato a piccole modifiche all'interfaccia.",
    },
    solution: {
      presentation:
        "[Qui potresti inserire il percorso di un'immagine o un componente React che mostra il progetto]",
      keyFeatures: [
        "Gestione intuitiva dei dati",
        "Interfaccia utente responsive",
        "Autenticazione utente sicura",
      ],
      challengeSolution:
        "La soluzione implementata ha fornito un'interfaccia chiara e facile da usare, consentendo agli utenti di gestire i dati in modo efficiente.",
    },
    results: {
      learnings:
        "Ho imparato molto sulla gestione di grandi quantità di dati nel frontend e sull'importanza della comunicazione efficace in un piccolo team.",
    },
    technologies: [
      "React",
      "Node.js",
      "Express",
      "MongoDB",
      "HTML5",
      "CSS",
      "JavaScript",
    ],
    personalReflections:
      "Sono particolarmente orgoglioso di come siamo riusciti a creare un'interfaccia utente complessa ma intuitiva entro i tempi stabiliti.",
    callToAction: "Dai un'occhiata al progetto live e al codice sorgente!",
    liveUrl: "https://tuo-progetto-live.com",
    codeUrl: "https://github.com/tuo-utente/tuo-progetto",
  },
  // Aggiungi i dati per le altre case study qui se ne hai
};

const ProjectDetail = () => {
  const { caseStudyId } = useParams<{ caseStudyId: string }>();
  const projectData = caseStudiesData[caseStudyId!]; // '!' perché sappiamo che l'ID sarà valido

  if (!projectData) {
    return <div>Progetto non trovato</div>; // Gestisci il caso in cui l'ID non corrisponde a nessuna case study
  }

  return <CaseStudy project={projectData} />;
};

export default ProjectDetail;
